﻿using IBS_DALayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace IBS_RSLayer
{
    /// <summary>
    /// Interface For Crud Operations (To be used every where:Generic class)
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ICustomerDb<T> where T : class
    {
        IEnumerable<T> ShowAll();
        T GetById(object Id);
        void Add(T TbObj);
        void Update(T TbObj);
        void Delete(object Id);

        IEnumerable<T> ShowAllById(object Id);
        T CreateUser(object Id);
        T GetAccountDetails(object Id);

        T GetByIdProcedure(object Id);
        void UpdateProcedure(T TbObj);

        CustomerAllDetail ShowCustomerDetail(object Id);
        IEnumerable<CustomerAllDetail> CustomerDetailsForAdmin();

    }
}
