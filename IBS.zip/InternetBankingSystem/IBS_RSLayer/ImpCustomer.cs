﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IBS_DALayer.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace IBS_RSLayer
{
    public class ImpCustomer<T> : ICustomerDb<T> where T : class
    {

        private InternetBankingSystemContext Database;
        private DbSet<T> Table;

        public ImpCustomer(InternetBankingSystemContext database)
        {
            Database = database;
            Table = database.Set<T>();
        }

        /// <summary>
        /// Fetches List of items in DataBase
        /// </summary>
        /// <returns>List</returns>
        public IEnumerable<T> ShowAll()
        {
            try
            {
                IEnumerable<T> Details = Table.ToList();
                return Details;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return null;
        }

        /// <summary>
        /// Fetches specific Detail from Database tables 
        /// </summary>
        /// <param name="Id">Id for which details have to be fetched</param>
        /// <returns>Details</returns>
        public T GetById(object Id)
        {
            try
            {
                T rec = Table.Find(Id);  
                if (rec != null)
                    return rec;
                else
                    throw new Exception("Invalid Entry");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return null;
        }

        /// <summary>
        /// To post changes or insert data to backend
        /// </summary>
        /// <param name="TbObj">Type of object to be inserted</param>
        public void Add(T TbObj)
        {
            try
            {
                Table.Add(TbObj);
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        /// <summary>
        /// To delete any specific entry from DataBase
        /// </summary>
        /// <param name="Id">ID for which details have to be deleted</param>
        public void Delete(object Id)
        {
            try
            {
                T rec = Table.Find(Id);
                if (rec != null)
                {
                    Table.Remove(rec);
                    Database.SaveChanges();
                }
                else
                {
                    throw new Exception("Record not foound!");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        public void Update(T TbObj)
        {
            try
            {
                Database.Entry(TbObj).State = EntityState.Modified;
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public IEnumerable<T> ShowAllById(object Id)
        {
            IEnumerable<T> AllTrans = null;
            try
            {

                SqlParameter parameter = new SqlParameter("@AccNo", Id);

                AllTrans = Table.FromSqlRaw<T>("ShowTransactionByAccNo @AccNo", parameter).ToList();
                if (AllTrans != null)
                {
                    
                    return AllTrans;
                }
                else
                {
                    throw new Exception("Record not foound!");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return AllTrans;
        }

        public T CreateUser(object Id)
        {
            T user = null;
            try
            {
                Random random = new Random();
                int pass = random.Next(1000000000, int.MaxValue);
                SqlParameter RequestId = new SqlParameter("@Request", Id);
                SqlParameter Password = new SqlParameter("@Password", pass);

                user = Table.FromSqlRaw<T>("RegisterUser @Request,@Password", RequestId,Password).ToList().FirstOrDefault();
                if (user != null)
                {
                    return user;
                }
                else
                {
                    throw new Exception("Record not found!");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return user;
        }

        public T GetAccountDetails(object Id)
        {
            T account = null;
            try
            {
                SqlParameter para = new SqlParameter("@UserId", Id);
                account = Table.FromSqlRaw<T>("GetAccountInfo @UserId", para).ToList().FirstOrDefault();
                if (account != null)
                {
                    return account;
                }
                else
                {
                    throw new Exception("Record not found!");
                }
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return account;
        }


        public CustomerAllDetail ShowCustomerDetail(object Id)
        {

            int AccNo = (int)Id;

            var detail = (from ad in Database.Set<AccountDetail>()
                          join pd in Database.Set<PersonalDetail>()

                          on ad.AccountNumber equals pd.AccountNumber

                          join nd in Database.Set<NomineeDetail>()

                          on ad.AccountNumber equals nd.AccountNumber
                          where ad.AccountNumber == AccNo
                          select new CustomerAllDetail
                          {
                              BranchName = ad.BranchName,
                              IFSCCode = ad.Ifsccode,
                              AccountType = ad.AccountType,
                              AccountBalance = ad.AccountBalance,
                              AccountNumber = ad.AccountNumber,
                              AccountCreationDate = ad.AccountCreationDate,
                              CustomerName = pd.CustomerName,
                              DOB = pd.Dob,
                              PhoneNumber = pd.PhoneNumber,
                              Email = pd.Email,
                              PAN = pd.Pan,
                              Aadhar = pd.Aadhar,
                              Address = pd.Address,
                              NomineeName = nd.NomineeName,
                              Relation = nd.Relation,
                              NomPhoneNumber = nd.PhoneNumber,
                              NomineeAddress = nd.NomineeAddress

                          }
                          ).ToList().FirstOrDefault();

            return detail;



        }

        public IEnumerable<CustomerAllDetail> CustomerDetailsForAdmin()
        {

            var detail = (from ad in Database.Set<AccountDetail>()
                          join pd in Database.Set<PersonalDetail>()

                          on ad.AccountNumber equals pd.AccountNumber

                          join nd in Database.Set<NomineeDetail>()

                          on ad.AccountNumber equals nd.AccountNumber

                          select new CustomerAllDetail
                          {
                              BranchName = ad.BranchName,
                              IFSCCode = ad.Ifsccode,
                              AccountType = ad.AccountType,
                              AccountBalance = ad.AccountBalance,
                              AccountNumber = ad.AccountNumber,
                              AccountCreationDate = ad.AccountCreationDate,
                              CustomerName = pd.CustomerName,
                              DOB = pd.Dob,
                              PhoneNumber = pd.PhoneNumber,
                              Email = pd.Email,
                              PAN = pd.Pan,
                              Aadhar = pd.Aadhar,
                              Address = pd.Address,
                              NomineeName = nd.NomineeName,
                              Relation = nd.Relation,
                              NomPhoneNumber = nd.PhoneNumber,
                              NomineeAddress = nd.NomineeAddress

                          }
                          ).ToList();

            return detail;

        }

        public void UpdateProcedure(T obj)
        {
            if (typeof(T).Name.Equals("PersonalDetail"))
            {

                List<SqlParameter> pms = new List<SqlParameter>();

                object v1 = typeof(T).GetProperty("CustomerId").GetValue(obj);
                pms.Add(new SqlParameter("@Cid", v1));

                object v2 = typeof(T).GetProperty("AccountNumber").GetValue(obj);
                pms.Add(new SqlParameter("@AccountNo", v2));

                object v3 = typeof(T).GetProperty("CustomerName").GetValue(obj);
                pms.Add(new SqlParameter("@Cname", v3));

                object v4 = typeof(T).GetProperty("Dob").GetValue(obj);
                pms.Add(new SqlParameter("@Dob", v4));

                object v5 = typeof(T).GetProperty("PhoneNumber").GetValue(obj);
                pms.Add(new SqlParameter("@PhoneNo", v5));

                object v6 = typeof(T).GetProperty("Email").GetValue(obj);
                pms.Add(new SqlParameter("@Email", v6));

                object v7 = typeof(T).GetProperty("Pan").GetValue(obj);
                pms.Add(new SqlParameter("@Pan", v7));

                object v8 = typeof(T).GetProperty("Aadhar").GetValue(obj);
                pms.Add(new SqlParameter("@Aadhar", v8));

                object v9 = typeof(T).GetProperty("Address").GetValue(obj);
                pms.Add(new SqlParameter("@Address", v9));

                Database.Database.ExecuteSqlRaw($"UpdatePersonalDetail @sid,@sname,@did", pms.ToList());

            }
        }

        public T GetByIdProcedure(object Id)
        {
            T PerDet = null;
            try
            {
                if (typeof(T).Name == "PersonalDetail")
                {
                    SqlParameter parameter = new SqlParameter("@AccountNo", Id);
                    PerDet = Database.Set<T>().FromSqlRaw("ShowPersonalDetailByAccNo @AccountNo", parameter).ToList().FirstOrDefault();
                    if (PerDet != null)
                    {
                        return PerDet;
                    }
                    else
                    {
                        throw new Exception("Record not foound!");
                    }
                }
                else if (typeof(T).Name == "NomineeDetail")
                {
                    SqlParameter parameter = new SqlParameter("@AccountNo", Id);
                    PerDet = Database.Set<T>().FromSqlRaw("ShowNomineeDetailByAccNo @AccountNo", parameter).ToList().FirstOrDefault();
                    if (PerDet != null)
                    {
                        return PerDet;
                    }
                    else
                    {
                        throw new Exception("Record not foound!");
                    }
                }
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return PerDet;


        }

        
    }
}
