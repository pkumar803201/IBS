﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class DebitCard
    {
        public decimal CardNumber { get; set; }
        public int? AccountNumber { get; set; }
        public string CardHolderName { get; set; }
        [DataType(DataType.Date)]
        public DateTime ExpiryDate { get; set; }
        public int Cvv { get; set; }
        public int? Pin { get; set; }

        public virtual AccountDetail AccountNumberNavigation { get; set; }
    }
}
