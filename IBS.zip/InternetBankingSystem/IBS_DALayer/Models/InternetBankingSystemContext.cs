﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class InternetBankingSystemContext : DbContext
    {
        private IConfiguration _configuration;
        public InternetBankingSystemContext()
        {
        }

        public InternetBankingSystemContext(DbContextOptions<InternetBankingSystemContext> options,IConfiguration configuration)
            : base(options)
        {
            _configuration = configuration;
        }

        public virtual DbSet<AccountCreationRequest> AccountCreationRequests { get; set; }
        public virtual DbSet<AccountDetail> AccountDetails { get; set; }
        public virtual DbSet<BranchDetail> BranchDetails { get; set; }
        public virtual DbSet<NomineeDetail> NomineeDetails { get; set; }
        public virtual DbSet<PersonalDetail> PersonalDetails { get; set; }
        public virtual DbSet<TransactionReport> TransactionReports { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //optionsBuilder.UseSqlServer("Server=Dipesh;Database=InternetBankingSystem;Trusted_Connection=True;");
                 optionsBuilder.UseSqlServer(_configuration.GetConnectionString("Connection"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccountCreationRequest>(entity =>
            {
                entity.HasKey(e => e.RequestId)
                    .HasName("ACR_RId_Pk");

                entity.ToTable("AccountCreationRequest");

                entity.HasIndex(e => e.Aadhar, "UQ__AccountC__6C9F238E350256B7")
                    .IsUnique();

                entity.HasIndex(e => e.Pan, "UQ__AccountC__C577943D6E6FC50A")
                    .IsUnique();

                entity.Property(e => e.Aadhar)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.AccountBalance).HasColumnType("money");

                entity.Property(e => e.AccountType)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.BranchName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CustAddress)
                    .IsRequired()
                    .HasMaxLength(120)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("DOB");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Ifsccode)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("IFSCCode");

                entity.Property(e => e.NomPhoneNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.NomineeAddress)
                    .IsRequired()
                    .HasMaxLength(120)
                    .IsUnicode(false);

                entity.Property(e => e.NomineeName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Pan)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("PAN");

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Relation)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('New')");
            });

            modelBuilder.Entity<AccountDetail>(entity =>
            {
                entity.HasKey(e => e.AccountNumber)
                    .HasName("AD_AId_Pk");

                entity.Property(e => e.AccountBalance).HasColumnType("money");

                entity.Property(e => e.AccountCreationDate).HasColumnType("date");

                entity.Property(e => e.AccountType)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.BranchName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Ifsccode)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("IFSCCode");

                entity.Property(e => e.LastCalculatedInterestDate).HasColumnType("date");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AccountDetails)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("AD_UId_Fk");
            });

            modelBuilder.Entity<BranchDetail>(entity =>
            {
                entity.HasKey(e => e.BranchName)
                    .HasName("BR_BName_Pk");

                entity.ToTable("BranchDetail");

                entity.Property(e => e.BranchName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Ifsccode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("IFSCCode");
            });

            modelBuilder.Entity<NomineeDetail>(entity =>
            {
                entity.HasKey(e => e.NomineeId)
                    .HasName("ND_NId_Pk");

                entity.Property(e => e.NomineeAddress)
                    .IsRequired()
                    .HasMaxLength(120)
                    .IsUnicode(false);

                entity.Property(e => e.NomineeName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Relation)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.HasOne(d => d.AccountNumberNavigation)
                    .WithMany(p => p.NomineeDetails)
                    .HasForeignKey(d => d.AccountNumber)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("ND_AId_Fk");
            });

            modelBuilder.Entity<PersonalDetail>(entity =>
            {
                entity.HasKey(e => e.CustomerId)
                    .HasName("PD_CId_Pk");

                entity.HasIndex(e => e.Aadhar, "UQ__Personal__6C9F238EF4BA88F9")
                    .IsUnique();

                entity.HasIndex(e => e.Pan, "UQ__Personal__C577943DC81B87C0")
                    .IsUnique();

                entity.Property(e => e.Aadhar)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(120)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("DOB");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Pan)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("PAN");

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.AccountNumberNavigation)
                    .WithMany(p => p.PersonalDetails)
                    .HasForeignKey(d => d.AccountNumber)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("PD_AId_Fk");
            });

            modelBuilder.Entity<TransactionReport>(entity =>
            {
                entity.HasKey(e => e.TransactionId)
                    .HasName("TR_Tid_Pk");

                entity.ToTable("TransactionReport");

                entity.Property(e => e.DateOfTransaction).HasColumnType("datetime");

                entity.Property(e => e.TransactionType)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(16)
                    .IsUnicode(false);

                entity.Property(e => e.UserType)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
