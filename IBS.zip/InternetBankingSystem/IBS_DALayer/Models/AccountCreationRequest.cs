﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class AccountCreationRequest
    {
        public int RequestId { get; set; }
        public string CustomerName { get; set; }
        [DataType(DataType.Date)]
        public DateTime Dob { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Pan { get; set; }
        public string Aadhar { get; set; }
        public string CustAddress { get; set; }
        public decimal AccountBalance { get; set; }
        public string BranchName { get; set; }
        public string Ifsccode { get; set; }
        public string AccountType { get; set; }
        public string NomineeName { get; set; }
        public string Relation { get; set; }
        public string NomPhoneNumber { get; set; }
        public string NomineeAddress { get; set; }
        public string Status { get; set; }
    }
}
