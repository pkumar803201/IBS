﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class TransactionReport
    {
        public int TransactionId { get; set; }
        public int? SenderAccountNo { get; set; }
        public int? Amount { get; set; }
        public int? RecieverAccountNo { get; set; }
        public string TransactionType { get; set; }
        public DateTime? DateOfTransaction { get; set; }
    }
}
