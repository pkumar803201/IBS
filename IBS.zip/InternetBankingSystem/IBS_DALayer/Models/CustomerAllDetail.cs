﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace IBS_DALayer.Models
{
    public class CustomerAllDetail
    {
        public string BranchName { get; set; }

        public string IFSCCode { get; set; }
        public string AccountType { get; set; }
        public decimal AccountBalance { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? AccountCreationDate { get; set; }
        public string CustomerName { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime DOB { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string PAN { get; set; }
        public string Aadhar { get; set; }
        public string Address { get; set; }
        public string NomineeName { get; set; }
        public string Relation { get; set; }
        public string NomPhoneNumber { get; set; }
        public string NomineeAddress { get; set; }
        public int AccountNumber { get; set; }
    }
}