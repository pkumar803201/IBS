﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class BranchDetail
    {
        public string BranchName { get; set; }
        public string Ifsccode { get; set; }
    }
}
