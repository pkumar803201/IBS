﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class NomineeDetail
    {
        public int NomineeId { get; set; }
        public string NomineeName { get; set; }
        public string Relation { get; set; }
        public string PhoneNumber { get; set; }
        public string NomineeAddress { get; set; }
        public int? AccountNumber { get; set; }

        public virtual AccountDetail AccountNumberNavigation { get; set; }
    }
}
