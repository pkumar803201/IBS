﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class AccountDetail
    {
        public AccountDetail()
        {
            NomineeDetails = new HashSet<NomineeDetail>();
            PersonalDetails = new HashSet<PersonalDetail>();
        }

        public int AccountNumber { get; set; }
        public decimal AccountBalance { get; set; }
        public string BranchName { get; set; }
        public string Ifsccode { get; set; }
        public string AccountType { get; set; }
        [DataType(DataType.Date)]
        public DateTime? AccountCreationDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime? LastCalculatedInterestDate { get; set; }
        public int? UserId { get; set; }

        public virtual User User { get; set; }
        public virtual ICollection<NomineeDetail> NomineeDetails { get; set; }
        public virtual ICollection<PersonalDetail> PersonalDetails { get; set; }
    }
}
