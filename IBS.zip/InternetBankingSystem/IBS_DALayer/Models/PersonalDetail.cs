﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class PersonalDetail
    {
        public int CustomerId { get; set; }
        public int? AccountNumber { get; set; }
        public string CustomerName { get; set; }
        [DataType(DataType.Date)]
        public DateTime Dob { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Pan { get; set; }
        public string Aadhar { get; set; }
        public string Address { get; set; }

        public virtual AccountDetail AccountNumberNavigation { get; set; }
    }
}
