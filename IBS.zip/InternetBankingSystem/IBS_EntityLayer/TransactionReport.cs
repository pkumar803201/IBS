﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class TransactionReport
    {
        public TransactionReport()
        {
            
        }
        public TransactionReport(int transactionId,int senderAccountNo,int amount,int receiverAccountNo,
            string transactionType,DateTime dateOfTransaction)
        {
            TransactionId = transactionId;
            SenderAccountNo = senderAccountNo;
            Amount = amount;
            RecieverAccountNo = receiverAccountNo;
            TransactionType = transactionType;
            DateOfTransaction = dateOfTransaction;


        }
        public int TransactionId { get; set; }
        public int? SenderAccountNo { get; set; }
        public int? Amount { get; set; }
        public int? RecieverAccountNo { get; set; }
        public string TransactionType { get; set; }
        public DateTime? DateOfTransaction { get; set; }
    }
}
