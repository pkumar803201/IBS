﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class DebitCard
    {
        public DebitCard()
        {

        }
        public DebitCard(decimal cardNumber,int accountNumber,string cardHolderName,DateTime expiryDate,
            int cvv,int pin)
        {
            CardNumber = cardNumber;
            AccountNumber = accountNumber;
            CardHolderName = cardHolderName;
            ExpiryDate = expiryDate;
            Cvv = cvv;
            Pin = pin;

        }
        public decimal CardNumber { get; set; }
        public int? AccountNumber { get; set; }
        public string CardHolderName { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int Cvv { get; set; }
        public int? Pin { get; set; }

        public virtual AccountDetail AccountNumberNavigation { get; set; }
    }
}
