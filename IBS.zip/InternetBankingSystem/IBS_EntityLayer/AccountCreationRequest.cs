﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class AccountCreationRequest
    {
        public AccountCreationRequest()
        {

        }
        public AccountCreationRequest(int requestId, string cusomerName, DateTime dob, decimal phoneNumber, string email,
            string pan, decimal adhar,string custAddress,decimal accountBalance,string branchName,string ifscCode,string accountType,
            string nomineeName,string relation,decimal nomPhoneNumber,string nomAddress)
        {
            RequestId=requestId ;
            CustomerName=cusomerName;
            Dob=dob;
            PhoneNumber=phoneNumber;
            Email=email;
            Pan=pan;
            Aadhar=adhar;
            CustAddress=custAddress;
            AccountBalance=accountBalance;
            BranchName=branchName;
            Ifsccode=ifscCode;
            AccountType=accountType;
            NomineeName=nomineeName;
            Relation=relation;
            NomPhoneNumber= nomPhoneNumber;
            NomineeAddress=nomAddress;

        }
        public int RequestId { get; set; }
        public string CustomerName { get; set; }
        public DateTime Dob { get; set; }
        public decimal PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Pan { get; set; }
        public decimal Aadhar { get; set; }
        public string CustAddress { get; set; }
        public decimal AccountBalance { get; set; }
        public string BranchName { get; set; }
        public string Ifsccode { get; set; }
        public string AccountType { get; set; }
        public string NomineeName { get; set; }
        public string Relation { get; set; }
        public decimal NomPhoneNumber { get; set; }
        public string NomineeAddress { get; set; }
    }
}
