﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class PersonalDetail
    {
        public PersonalDetail()
        {

        }
        public PersonalDetail(int customerId,int accountNumber,string customerName,DateTime dob,
            decimal phoneNumber,string email,string pan,decimal aadhar,string address)
        {
            CustomerId = customerId;
            AccountNumber = accountNumber;
            CustomerName = customerName;
            Dob = dob;
            PhoneNumber = phoneNumber;
            Email = email;
            Pan = pan;
            Aadhar = aadhar;
            Address = address;

        }
        public int CustomerId { get; set; }
        public int? AccountNumber { get; set; }
        public string CustomerName { get; set; }
        public DateTime Dob { get; set; }
        public decimal PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Pan { get; set; }
        public decimal Aadhar { get; set; }
        public string Address { get; set; }

        public virtual AccountDetail AccountNumberNavigation { get; set; }
    }
}
