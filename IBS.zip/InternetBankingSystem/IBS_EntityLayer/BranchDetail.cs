﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class BranchDetail
    {
        public BranchDetail()
        {

        }
        public BranchDetail(string branchName,string ifscCode)
        {
            BranchName = branchName;
            Ifsccode = ifscCode;
        }
        public string BranchName { get; set; }
        public string Ifsccode { get; set; }
    }
}
