﻿using System;
using System.Collections.Generic;

#nullable disable

namespace IBS_DALayer.Models
{
    public partial class User
    {
        public User()
        {
            AccountDetails = new HashSet<AccountDetail>();
        }
        public User(int userId,string password,string userType)
        {
            AccountDetails = new HashSet<AccountDetail>();
            UserId = userId;
            Password = password;
            UserType = userType;

        }

        public int UserId { get; set; }
        public string Password { get; set; }
        public string UserType { get; set; }

        public virtual ICollection<AccountDetail> AccountDetails { get; set; }
    }
}
