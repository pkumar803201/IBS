﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IBS_EXLayer
{
    public class MoneyTransactionException : Exception
    {
        public MoneyTransactionException()
       : base()
        {
        }

        public MoneyTransactionException(string message)
            : base(message)
        {
            
        }
        public MoneyTransactionException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
