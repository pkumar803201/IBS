﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IBS_EXLayer
{
    public class TransactionReportException : Exception
    {
        public TransactionReportException()
      : base()
        {
        }

        public TransactionReportException(string message)
            : base(message)
        {
        }
        public TransactionReportException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
