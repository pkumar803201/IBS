﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IBS_EXLayer
{
    public class InterestCalculationException : Exception
    {
        public InterestCalculationException()
       : base()
        {
        }

        public InterestCalculationException(string message)
            : base(message)
        {
        }
        public InterestCalculationException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
