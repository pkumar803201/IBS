﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IBS_EXLayer
{
    public class AccountCreationException:Exception
    {
        public AccountCreationException()
          : base()
        {
        }

        public AccountCreationException(string message)
            : base(message)
        {
           
        }
        public AccountCreationException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
