﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IBS_EXLayer
{
    public class CustomerDetailsException : Exception
    {
        public CustomerDetailsException()
         : base()
        {
        }

        public CustomerDetailsException(string message)
            : base(message)
        {
        }
        public CustomerDetailsException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
