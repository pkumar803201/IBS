﻿namespace IBS_UILayer.BAServices
{
    public class MoneyTransactionService
    {

    }
}
